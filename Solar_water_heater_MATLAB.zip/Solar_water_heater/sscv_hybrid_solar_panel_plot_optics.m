% Code to plot solar_panel optical characteristics of the glass cover: reflection, absorption and transmission coefficients in function of incidence angle

%% Generate data for figure

angle = linspace(0, pi/2, 500);

[Reflg, Absg, Transg] = optics(angle, panel);


%% Create figure

if ~exist('figHandleOptics', 'var') || ~isgraphics(figHandleOptics, 'figure')
    figHandleOptics=figure('Name','hybrid_solar_panel_optics');
end

figure(figHandleOptics);
clf(figHandleOptics);
set(figHandleOptics, 'Position', [450  60   540   590]);

subplot(3,1,1);
plot(angle*180/pi, Reflg, 'Color', [0 0 1], 'LineWidth', 1.5);
title('Reflection coefficient');
grid on
box on

subplot(3,1,2);
plot(angle*180/pi, Absg, 'Color', [0 0.3 0.7], 'LineWidth', 1.5);
title('Absorption coefficient');
grid on
box on

subplot(3,1,3);
plot(angle*180/pi, Transg, 'Color', [0 0.6 0.4], 'LineWidth', 1.5);
title('Transmission coefficient');
xlabel('Incidence angle (deg)');
grid on
box on


%% Optics model
function [Reflg, Absg, Transg] = optics(angle, panel)

    ng = panel.optical.ng;
    absg = panel.optical.absg;
    dg = panel.optical.dg;
    
    % Fresnel equations 1st boundary
    r1p =  ( ng^2*cos(angle) - sqrt(ng^2 - sin(angle).^2) ).^2./( ng^2*cos(angle) + sqrt( ng^2 - sin(angle).^2 ) ).^2; %P polarization
    r1s =  ( cos(angle) - sqrt(ng^2 - sin(angle).^2) ).^2./( cos(angle) + sqrt( ng^2 - sin(angle).^2 ) ).^2; %S polarization
    r1 = 0.5*(r1p + r1s); %Effective reflectance
    t1 = 1-r1;

    nga = 1/ng; %refractive index glass -> air
    th2 = asin(sin(angle)/ng);  %Snell's law to compute angle of incidence on 2nd boundary

    % Fresnel equations 2nd boundary
    r2p = ( nga^2*cos(th2) - sqrt(nga^2 - sin(th2).^2) ).^2./( nga^2*cos(th2) + sqrt( nga^2 - sin(th2).^2 ) ).^2 ;
    r2s = ( cos(th2) - sqrt(nga^2 - sin(th2).^2) ).^2./( cos(th2) + sqrt( nga^2 - sin(th2).^2 ) ).^2 ;
    r2 = 0.5*(r2p + r2s); %Effective reflectance
    t2 = 1 - r2;

    taug = exp(-absg*dg./cos(th2)); 

    %Total coefficients for infinite reflections between 2 parallel boundaries
    Transg = t1.*taug.*t2./(1 - r1.*r2.*taug.^2);
    Reflg = r1 + (t1.^2.*taug.^2.*r2)./(1 - r1.*r2.*taug.^2);
    Absg = 1 - Transg - Reflg; 
end
