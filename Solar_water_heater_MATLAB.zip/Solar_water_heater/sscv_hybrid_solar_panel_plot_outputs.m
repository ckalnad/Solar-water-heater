% Code to plot solar_panel outputs, which are: temperatures of the thermal masses, useful power (electrical and thermal) and tank volume.

%% Setup
model = 'sscv_hybrid_solar_panel';

if ~strcmp(bdroot, model)
    load_system(model);
    set_param(0, 'CurrentSystem', model);
end

%% Generate data for figure
if ~exist('out', 'var')
    out = sim(model);
end

tout = out.tout;

Tg_series = out.simlog_hybrid_solar_panel.Glass.T.series.values;
Tpv_series = out.simlog_hybrid_solar_panel.Solar_Cell.temperature.series.values;
Te_series = out.simlog_hybrid_solar_panel.Exchanger.T.series.values;
Tb_series = out.simlog_hybrid_solar_panel.Back.T.series.values;
Tw_series = out.simlog_hybrid_solar_panel.Tank.T_tank.series.values;

Pow_elec_series = out.simlog_hybrid_solar_panel.Load.Voltage_Sensor.V.series.values .* ...
    out.simlog_hybrid_solar_panel.Load.Current_Sensor.I.series.values;

Pow_therm_series = out.simlog_hybrid_solar_panel.Sensor1.Mass_Energy_Flow_Rate_Sensor_TL.PHI.series.values ...
    - out.simlog_hybrid_solar_panel.Sensor1.Mass_Energy_Flow_Rate_Sensor_TL1.PHI.series.values;

Voltank_series = out.simlog_hybrid_solar_panel.Tank.volume.series.values;

%% Create figure

%Temperatures
if ~exist('figHandleOutputs', 'var') || ~isgraphics(figHandleOutputs, 'figure')
    figHandleOutputs=figure('Name','hybrid_solar_panel_outputs');
end

figure(figHandleOutputs);
clf(figHandleOutputs);
set(figHandleOutputs, 'Position', [15,   60,   770,   480]);

%Temperatures
subplot(3,1,1);
plot(tout/3600, Tg_series, '--', 'Color', [1 0 0], 'LineWidth', 1.5);
hold on
plot(tout/3600, Tpv_series, ':', 'Color', [1 0.2 0], 'LineWidth', 1.5);
plot(tout/3600, Te_series, '-.', 'Color', [1 0.4 0], 'LineWidth', 1.5);
plot(tout/3600, Tb_series, '-', 'Color', [1 0.6 0], 'LineWidth', 1.5);
plot(tout/3600, Tw_series, '-', 'Color', [1 0.8 0], 'LineWidth', 1.5);
legend('Glass', 'Solar cells', 'Exchanger', 'Back', 'Tank water');
title('Temperatures');
%xlabel('Time [h]');
ylabel('[K]');
grid on
box on


%Power
subplot(3,1,2);
plot(tout/3600, Pow_elec_series,  'Color', [0, 0.1, 1]	, 'LineWidth', 1.5);
hold on
plot(tout/3600, Pow_therm_series, '-.',  'Color', [0, 0.6, 1]	, 'LineWidth', 1.5);
legend('Eletrical power to load', 'Thermal power to demanded water')
title('Useful Power');
%xlabel('Time [h]');
ylabel('[W]');
grid on
box on


%Volume
subplot(3,1,3);
plot(tout/3600, Voltank_series, 'Color', [0, 0.7, 0], 'LineWidth', 1.5);
title('Water volume in the tank');
xlabel('Time [h]');
ylabel('[m^3]');
grid on
box on

