% Code to calculate ee_hybrid_solar_panel efficiency: useful electrical and thermal energy vs. total energy supplied to the panel from the sun.


%% Setup
model = 'sscv_hybrid_solar_panel';

if ~strcmp(bdroot, model)
    load_system(model);
    set_param(0, 'CurrentSystem', model);
end

%% Generate data
if ~exist('out', 'var')
    out = sim(model);
end

tout = out.tout;

solar_irradiance_series = out.ScopeSolar.signals(1).values;
solar_inclination_series = out.ScopeSolar.signals(2).values;

Pow_input_series = panel.geometry.Ncell*panel.geometry.Acell*...
    solar_irradiance_series.*cos(solar_inclination_series); %cos() is an 
% area correction from projected surface seen by the sun

Pow_elec_series = out.simlog_hybrid_solar_panel.Load.Voltage_Sensor.V.series.values .* ...
    out.simlog_hybrid_solar_panel.Load.Current_Sensor.I.series.values;

Pow_therm_series = out.simlog_hybrid_solar_panel.Sensor1.Mass_Energy_Flow_Rate_Sensor_TL.PHI.series.values;

Pow_therm_source_series = out.simlog_hybrid_solar_panel.Sensor2.Mass_Energy_Flow_Rate_Sensor_TL.PHI.series.values;


%% Compute efficiency

E_input = trapz(tout, Pow_input_series)/(3.6E6); %[kWh]
E_elec = trapz(tout, Pow_elec_series)/(3.6E6); %[kWh]
E_therm = trapz(tout, Pow_therm_series)/(3.6E6); %[kWh]
E_therm_source = trapz(tout, Pow_therm_source_series)/(3.6E6); %[kWh]

stptime = evalin('base', (get_param(model, 'StopTime')))/(24*3600); %[days]

fprintf('\n');
fprintf('****** Efficiency Calculation *********\n');
fprintf('\n');
fprintf(['Total input energy from the sun in the period: ', num2str(E_input), ' kWh \n']);
fprintf(['Average input energy from the sun per day: ', num2str(E_input/stptime), ' kWh/day \n']);
fprintf('\n');
% Uncomment if you want electrical load to work
% fprintf(['Total electrical energy supplied to the load: ', num2str(E_elec), ' kWh \n']);
% fprintf(['Average electrical energy supplied per day: ', num2str(E_elec/stptime), ' kWh/day \n']);
% fprintf('\n');
fprintf(['Total absolute thermal energy in the water supplied to the user: ', num2str(E_therm), ' kWh \n']);
fprintf(['Total absolute thermal energy in the water extracted from the source: ', num2str(E_therm_source), ' kWh \n']);
fprintf('\n');
fprintf(['Total used thermal energy (sink - source): ', num2str(E_therm - E_therm_source), ' kWh \n']);
fprintf(['Average used thermal energy per day (sink - source): ', num2str((E_therm - E_therm_source)/stptime), ' kWh/day \n']);
fprintf('\n');
% Uncomment if you want electrical load to work
% fprintf(['Electrical efficiency: ', num2str(E_elec/E_input), ' \n']);
fprintf(['Thermal efficiency: ', num2str((E_therm - E_therm_source)/E_input), ' \n']);
fprintf(['Total efficiency: ', num2str((E_elec + E_therm - E_therm_source)/E_input), ' \n']);
fprintf('\n');
fprintf('***************************************\n');


