% Code to plot solar_panel inputs, which are solar variables and pump flows

%% Setup
model = 'sscv_hybrid_solar_panel';

if ~strcmp(bdroot, model)
    load_system(model);
    set_param(0, 'CurrentSystem', model);
end

%% Generate data for figures

solar_irradiance_t = evalin('base', (get_param(...
    [model, '/Solar inputs/solar_irradiance'], 'rep_seq_t')));

solar_irradiance_y = evalin('base', (get_param(...
    [model, '/Solar inputs/solar_irradiance'], 'rep_seq_y')));

solar_inclination_t = evalin('base', (get_param(...
    [model, '/Solar inputs/solar_inclination'], 'rep_seq_t')));

solar_inclination_y = evalin('base', (get_param(...
    [model, '/Solar inputs/solar_inclination'], 'rep_seq_y')));


internal_flow_t = evalin('base', (get_param(...
    [model, '/Pump flow inputs/internal_flow'], 'rep_seq_t')));

internal_flow_y = evalin('base', (get_param(...
    [model, '/Pump flow inputs/internal_flow'], 'rep_seq_y')));

demand_t = evalin('base', (get_param(...
    [model, '/Pump flow inputs/demand'], 'rep_seq_t')));

demand_y = evalin('base', (get_param(...
    [model, '/Pump flow inputs/demand'], 'rep_seq_y')));

supply_t = evalin('base', (get_param(...
    [model, '/Pump flow inputs/supply'], 'rep_seq_t')));

supply_y = evalin('base', (get_param(...
    [model, '/Pump flow inputs/supply'], 'rep_seq_y')));

%% Create figures

%Solar
if ~exist('figHandleSolarInputs', 'var') || ~isgraphics(figHandleSolarInputs, 'figure')
    figHandleSolarInputs=figure('Name','hybrid_solar_panel_solar_inputs');
end

figure(figHandleSolarInputs);
clf(figHandleSolarInputs);
set(figHandleSolarInputs, 'Position', [90   250   430   430]);

subplot(2,1,1);
plot(solar_irradiance_t/3600, solar_irradiance_y, 'r', 'LineWidth', 1.5);
xlim([0, 24]);
title('Solar Irradiance');
xlabel('Time [h]');
ylabel('Irradiance [W/m^2]');
grid on
box on

subplot(2,1,2);
plot(solar_inclination_t/3600, solar_inclination_y, ...
    'Color', [0.9290, 0.6940, 0.1250]	, 'LineWidth', 1.5);
xlim([0, 24]);
title('Solar Inclination');
xlabel('Time [h]');
ylabel('Absolute angle [rad]');
grid on
box on

%Pumps
if ~exist('figHandlePumpInputs', 'var') || ~isgraphics(figHandlePumpInputs, 'figure')
    figHandlePumpInputs=figure('Name','hybrid_solar_panel_pumps_inputs');
end

figure(figHandlePumpInputs);
clf(figHandlePumpInputs);
set(figHandlePumpInputs, 'Position', [520  250   430   430]);

subplot(3,1,1);
plot(internal_flow_t/3600, internal_flow_y, 'c', 'LineWidth', 1.5);
xlim([0, 24]);
title('Internal flow');
ylabel('mass flow rate [kg/s]');
grid on
box on

subplot(3,1,2);
plot(demand_t/3600, demand_y, 'b', 'LineWidth', 1.5);
xlim([0, 24]);
title('Demand');
ylabel('mass flow rate [kg/s]');
grid on
box on

subplot(3,1,3);
plot(supply_t/3600, supply_y, 'm', 'LineWidth', 1.5);
xlim([0, 24]);
title('Supply');
xlabel('Time [h]');
ylabel('mass flow rate [kg/s]');
grid on
box on

